from . import test_common
from . import test_edi_common
from . import test_edi_format
from . import test_l10n_ec_edi_key_type
from . import test_l10n_ec_edi_out_invoice
from . import test_l10n_ec_edi_liquidation
from . import test_l10n_ec_edi_credit_note
from . import test_l10n_ec_edi_debit_note
